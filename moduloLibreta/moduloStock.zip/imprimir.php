<?php
session_start();
ob_start();
require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;
    if (isset($_SESSION['imprimir'])) {
      
    }else{
      header("location: stock.php");
    }
?>
<?php
 
?>

<html>
  <head>
    <title>Impreciones info</title>
  </head>
<body>  

  <!--  <img src="<?php echo $imagenBase64?>" style="width: 100%;" alt=""> -->
  <h4 style="text-align: right;">FECHA <?php echo date("d-m-Y")?></h4>
  <div>
           <h2 style="text-align: center;"><?php echo "PRODUCTOS EN STOCK"?></h2>
         </div>
    <div>
      <hr>
     
     

    </div>
    <div>
      <table style="width:100%;" border="1" CELLPADDING=10 CELLSPACING=0>
          <thead>
              <tr>
                  <th>Articulo</th>
                  <th>En stock</th>
        <!--           <th>Hora de consulta</th> -->
              </tr>
          </thead>
        <tbody>
          <?php foreach ($_SESSION['imprimir'] as $key):?>
          <tr>
            <?php
            $bulto=floor(($key['cantidad']) / $key['unidad']);
            $unidad=$bulto*$key['unidad'];
            $unidad=($key['cantidad'])-$unidad;
            
            ?>
            <td style="padding: 2px;"><?php echo strtoupper($key['nombre'])?></td>
            <td style="padding: 2px;"><?php echo ($key['unidad']>1)?$bulto."p"."/".$unidad."u":$key['cantidad']."u"?></td>
            <!-- <td style="padding: 2px;"><?php echo $key['domicilio']?></td> -->
            <!-- <td style="padding: 2px;"><?php echo $key['fecha_hora']?></td> -->
          </tr>
          <?php endforeach?>
        </tbody>
         
      </table>
    </div>
          
</body>
</html>
<?php
$dompdf = new Dompdf();
$dompdf->loadHtml(ob_get_clean());
$dompdf->setPaper('A4', 'portrait'); // (Opcional) Configurar papel y orientaci車n
$dompdf->render(); // Generar el PDF desde contenido HTML
$pdf = $dompdf->output();// Obtener el PDF generado
$date="control de patentes ".date("d-m-Y");
$dompdf->stream($date,array("Attachment" => false));
?>
